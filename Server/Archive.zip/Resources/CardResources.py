## CardResources.py  (our custom Resources, not to be confused with Twisteds)
## This way we can keep the crypto out of this file
## and hopefully make life easier.
## Naming Conventions: PEP 08 and PEP 20

import hashlib
import time
import json
import glob
### LOGGING
from twisted.python import log

### TEMPLATES
from twisted.web.template import Element, renderer, XMLFile, tags, TagLoader, Comment
from twisted.web.template import flatten

### RESOURCES
import twisted.web
from twisted.web.server import Site
from twisted.web.server import NOT_DONE_YET # magic value for persistant connection
from twisted.web.static import File
from twisted.web.resource import Resource, NoResource
from twisted.web.util import redirectTo

### REACTOR
from twisted.internet import reactor

INC = 22
IDs = {}
GAMEs = {}

# Main Resource, deals with certain things that have to be setup
class CardsResource(Resource):

    def render(self, request):
        print "RENDER CARD RESOURCES\n\n\n\n\n\n\n"
        global INC
        global IDs
        global GAMEs
        INC = INC + 1
        print IDs
        # make sure there is a session id cookie
        cookie = request.getCookie("platypus_id")
        print "CCOKIE"
        print cookie
        print IDs.has_key(cookie)
        not_in_db = not IDs.has_key(cookie)
        if cookie == None or not_in_db:
            # give them a cookie
            print "Setting cookie"
            cookie = hashlib.sha256(str(INC))
            cookie.update(str(time.time()))
            cookie.update("ASDLFK443W34T623SF")
            cookie = cookie.hexdigest()
            print "A COOKIE"
            print cookie
            # SID - Session ID
            print cookie
            IDs[cookie] = []
            print IDs
            expiration_time = time.strftime('%a, %d %b %Y %H:%M:%S GMT', time.gmtime(time.time() + 3600 * 2))
            request.addCookie("platypus_id", cookie, expiration_time) 

            #                               httpOnly = True, # not accisable by javascript

        else:
            # ok we have a cookie
            # ignore
            pass 
        return Resource.render(self, request)        

### API
from Games.TexasHoldem import getHands, generateDeck
class TH4Player(object):

    def __init__(self):
        self.deck = generateDeck()
        self.hands = getHands(4, 2, self.deck)
        ri = 4 * 2
        self.river = self.hands[ri:ri+5]
        self.money = [5000, 5000, 5000, 5000]
        self.player_count = 0
        self.players = []
        self.round = 0
        print self.hands
        print self.river
        print self.money

    def reg_player(self, id):
        self.player_count = self.player_count + 1
        self.players.append(id)
    def get_hand(self, player):
        return self.hands[player]

    def inc_round(self ):
        self.round = self.round + 1

    def get_river(self):
        return self.river[self.round]

    def do_bet(self, player, amount):
        give = self.amount[player]
        if give > amount:
            give = give - amount
            self.amount[player] = give
            print "Player %s has %s left" % (player, give)
            return give
        else:
            raise RuntimeError("Too big of a bet")

i = 0

class API(CardsResource):
    '''Virtual Directory for api'''
    isLeaf = False
    def render_GET(self, request):
        return "<html><h1>API</h1></html>"

    def render_POST(self, request):
        print request.args
        if request.args["type"][0] == "pa":
            v = request.args["verb"][0]
            if v == "bet":
                try:
                    amount = request.args["amount"]
                    cookie = request.getCookie("platypus_id")
                    print "GOT COOKIE"
                    print IDs
                    print IDs[cookie]
                    game_id = IDs[cookie][0]
                    g = GAMEs[game_id]
                    give = g.do_bet(int(amount))
                except:
                    log.err()
                    d = {}
                    d["success"] = False
                    d["reason"] = "Too big of a bet"
                else:
                    d = {}
                    d["success"] = True
                    d["amount"] = give
                str = json.dumps(d)
                return str

            if v == "draw":
                try:
                    cookie = request.getCookie("platypus_id")
                    print "GOT COOKIE"
                    print IDs
                    print IDs[cookie]
                    game_id = IDs[cookie][0]
                    g = GAMEs[game_id]
                    p = g.players.index(cookie)
                    print "GAME ID"
                    print game_id
                    print "PLAYERs"
                    print p
                    hand = g.get_hand(int(p))
                except:
                    log.err()
                    d = {}
                    d["success"] = False
                    d["reason"] = "Unkown"
                else:
                    d = {}
                    d["success"] = True
                    d["hand"] = hand
                    global i
                    i = i + 1
                    print "i\n\n\n\n\n\n\n\n\n\n"
                    print i
                    if i == 1:
                        d["images"] = ["card_images/ace_of_clubs.png", "card_images/jack_of_hearts.png"]
                    else:
                        d["images"] = ["card_images/2_of_clubs.png", "card_images/ace_of_hearts.png"]
                    """
                    for i in hand:
                        p = list(i)
                        s = "html/card_images/%s*_of_%s*.png" % (p[1].lower(), p[0].lower())
                        print s
                        print glob.glob(s)
                        print glob.glob(s)[0]
                        print glob.glob(s)[0].replace("html/", "")
                        d["images"].append( glob.glob(s)[0].replace("html/", ""))
                    """
                str = json.dumps(d)
                print str
                return str
                
        return str(request.args)


class Users(CardsResource):
    '''Renders a users page'''
    isLeaf = False
    def render_GET(self, request):
        return "<html><h1>User</h1></html>"

class Game(CardsResource):
    '''Renders the game app'''
    isLeaf = False
    def render_GET(self, request):
        a = request.args
        try:
            id = a["gid"]
            c = request.getCookie("platypus_id")
            assert c != None
        except:
            log.err()
        else:
            print "ID - GAME"
            print id
            print c

        print IDs
        IDs[c].append(c)
        print IDs
        try:
            g = GAMEs[c]
            g.reg_player(c)
        except:
            g = TH4Player()
            GAMEs[c] = g
            g.reg_player(c)

        return File("html/game.html").render_GET(request)

class PersistantExample(CardsResource):
    '''Gives an example of a persistant request'''
    # does not exist on Safari until stopping browser / ending connection

    isLeaf = True
    def render_GET(self, request):
        log.msg("Ooooh a render request")
        # schedule the reoccuring thing (this could be something else like a deferred result)
        reactor.callLater(1.1, self.keeps_going, request, 0) # 1.1 seconds just to show it can take floats
        request.responseHeaders.addRawHeader("Content-Type", "text/html; charset=utf-8") # set the MIME header
        request.responseHeaders.addRawHeader("Connection", "keep-alive")
        #request.responseHeaders.addRawHeader("Content-Length", "700")
        # firefox requirest the char set see https://bugzilla.mozilla.org/show_bug.cgi?id=647203
        request.write("<html>\n<title>PE</title>\n<body>")
        return NOT_DONE_YET


    def keeps_going(self, request, i):
        log.msg("I'm going again....")
        i = i + 1
        request.write("\n<br> This is the %sth time I've written. </br>" % i) ## probably not best to use <br> tag
        
        if i < 5:
            reactor.callLater(1.1, self.keeps_going, request, i) # 1.1 seconds just to show it can take floats
        if i >= 5 and not request.finished:
            request.write("\n</body>")
            request.write("\n</html>")
            # safari will only render when finished
            request.finish()

class AndrewExample(CardsResource):
    '''Gives an example of a persistant request'''
    isLeaf = True
    def render_GET(self, request):
        '''
        request.responseHeaders.addRawHeader("Content-Type", "text; charset=utf-8") # set the MIME header
        d = {}
        d["success"] = True
        d["hand"] = True
        d["data"] = [1, 2, 5, 7, 674, 6]

        import json
        s = json.dumps(d)
        print s
        return s
        '''
        html = '''
        <form action="ae" method="post">
        First name:<br>
        <input type="text" name="firstname" value="Mickey">
        <br>
        Last name:<br>
        <input type="text" name="lastname" value="Mouse">
        <br><br>
        <input type="submit" value="Submit">
        </form> 
        '''
        return html


    def render_POST(self, request):
        request.responseHeaders.addRawHeader("Content-Type", "text; charset=utf-8") # set the MIME header        
        args = request.args
        f = args["firstname"][0]
        l = args["lastname"][0]
        import json
        if f.lower() == "donald" and l.lower() == "duck":
            d = {}
            d["valid"] = True
            return json.dumps(d)

        else:
            d = {}
            d["valid"] = False
            return json.dumps(d)



## HOME PAGE

class Home(CardsResource):
    isLeaf = False
    def render_GET(self, request):
        return "<html><center><h1>Hi!</h1><img src=\"logo.png\" width=\"400\"></center></html>"



def Create(root):
    ## probably should find a better name for this function
    logo = File("/Users/davidmorehouse/Desktop/platypus-logo-anni-2.png")
    api = API();

    # various representions of the home page
    root.putChild("", root)
    root.putChild("index.html", root)
    root.putChild("index", root)

    root.putChild("pe", PersistantExample())
    root.putChild("ae", AndrewExample())
    root.putChild("test", File("test.html"))
    # platypus image
    root.putChild("logo.png", logo)

    # app specific pages
    root.putChild("user", Users())
    root.putChild("game", Game())


    # api
    root.putChild("api", api)

    import glob
    for i in glob.glob("html/*"):
        print i
        root.putChild(i.replace("html/", ""), File(i))