# make this a module
# python will then natively recognize this structure
# this file can be empty (or used to intialize the module)

